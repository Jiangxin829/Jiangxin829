#include "FIFO.h"

int main()
{
	cout << "-------------------------->>FCFS<<------------------------------------" << endl;
	vector<Task> vecOfTask = { { 1,0,2 } ,{2,3,7},{3,4,1},{4,5,4} };
	string result = FIFO(vecOfTask);
	cout << result << endl;


	cout << "------------------------->>ShortestFirst<<----------------------------" << endl;
	vecOfTask = { { 1,0,5 } ,{ 2,0,1 },{ 3,3,3 },{ 4,15,2 },{ 5,14,2 } };
	result = ShortestFirst(vecOfTask);
	cout << result << endl;

	cout << "------------------------->>RR<<----------------------------" << endl;
	vecOfTask = { { 1,0,5 } ,{ 2,0,1 },{ 3,3,3 },{ 4,15,7 },{ 5,14,7 } };
	result = RR(vecOfTask);
	cout << result << endl;

	getchar();
	return 0;
}

bool CompByRequestTime(const Task& t1, const Task& t2) 
{
	return t1.requestTime_ < t2.requestTime_;
}
bool CompByServerTime(const Task& t1, const Task& t2)
{
	if (t1.serverTime_ != t2.serverTime_)
	{
		return t1.serverTime_ < t2.serverTime_;
	}
	else
	{
		return t1.requestTime_ < t2.requestTime_;
	}
}

string FIFO(const vector<Task>& vecTask)
{
	vector<Task>vecTaskList(vecTask);
	sort(vecTaskList.begin(), vecTaskList.end(), CompByRequestTime);

	string describeOfTask;
	int time = 0;

	vector<Task>::const_iterator iter = vecTaskList.begin();
	while (iter != vecTaskList.end())
	{
		//������ʱ������������ֱ����ת����һ�����������ʱ��
		if (time < iter->requestTime_)
		{
			time = iter->requestTime_;
		}

		describeOfTask += "This is No " + to_string(iter->index_) + " Task" 
			+ "\tRequestTime is " + to_string(iter->requestTime_)
			+ "\tOccurTime is " + to_string(time)	
			+ "\tServerTime is " + to_string(iter->serverTime_)
			+ "\tEndTime is " + to_string(time+iter->serverTime_)
			+ ".\n";

		time += iter->serverTime_;
		iter++;
	}

	return describeOfTask;
}

string ShortestFirst(const vector<Task>& vecTask)
{
	string describeOfTask;
	vector<Task>vecTaskList(vecTask);
	vector<Task>vecAlreadyList;
	sort(vecTaskList.begin(), vecTaskList.end(), CompByRequestTime);

	
	int time = 0;

	vector<Task>::iterator iter = vecTaskList.begin();
	vector<Task>::iterator workTask;
	while(vecTaskList.size() != 0 || vecAlreadyList.size() != 0)
	{
		while(vecTaskList.size() != 0)
		{
			//ȡ����ǰʱ���Ѿ���ʼ����Ľ��̵���������
			if (time >= iter->requestTime_)
			{
				vecAlreadyList.push_back(*iter);
				vecTaskList.erase(iter);
				iter = vecTaskList.begin();
				continue;
			}
			break;
		}
		//�����ǰ������Ľ��̣�ʱ�����ֱ���ҵ���һ�����̿�ʼ����
		if (vecAlreadyList.size() == 0)
		{
			++time;
			continue;
		}
		
		//�Ե�ǰ��������Ľ��̽��з���ʱ�������
		sort(vecAlreadyList.begin(), vecAlreadyList.end(), CompByServerTime);
		//ȡ����ʱ����̵Ľ��̽��з���
		workTask = vecAlreadyList.begin();

		describeOfTask += "This is No " + to_string(workTask->index_) + " Task"
			+ "\tRequestTime is " + to_string(workTask->requestTime_)
			+ "\tOccurTime is " + to_string(time)
			+ "\tServerTime is " + to_string(workTask->serverTime_)
			+ "\tEndTime is " + to_string(time + workTask->serverTime_)
			+ ".\n";

		time += workTask->serverTime_;
		vecAlreadyList.erase(workTask);	
	}

	return describeOfTask;
}

string RR(const vector<Task>& vecTask)
{
	string describeOfTask;
	vector<Task>vecTaskList(vecTask);
	vector<Task>vecAlreadyList;
	sort(vecTaskList.begin(), vecTaskList.end(), CompByRequestTime);


	int time = 0;
	const int  ALLOCATE_TIME = 3;
	Task temp{ 0,0,0 };

	vector<Task>::iterator iter = vecTaskList.begin();
	vector<Task>::iterator workTask;
	while (vecTaskList.size() != 0 || vecAlreadyList.size() != 0)
	{
		while (vecTaskList.size() != 0)
		{
			if (time >= iter->requestTime_)
			{
				vecAlreadyList.push_back(*iter);
				vecTaskList.erase(iter);
				iter = vecTaskList.begin();
				continue;
			}
			break;
		}
		//�ڵ�ǰ�������к������֮ǰδ��ɵĽ���
		if (temp.serverTime_ != 0)
		{
			vecAlreadyList.push_back(temp);
			temp = { 0,0,0 };
		}

		if (vecAlreadyList.size() == 0)
		{
			++time;
			continue;
		}
		
		workTask = vecAlreadyList.begin();
		if (workTask->serverTime_ > ALLOCATE_TIME)
		{
			temp = *workTask;
			temp.serverTime_ -= ALLOCATE_TIME;

			describeOfTask += "This is No " + to_string(workTask->index_) + " Task"
				+ "\tRequestTime is " + to_string(workTask->requestTime_)
				+ "\tOccurTime is " + to_string(time)
				+ "\tServerTime is " + to_string(ALLOCATE_TIME)
				+ "\tEndTime is " + to_string(time + ALLOCATE_TIME)
				+ ".\n";

			time += ALLOCATE_TIME;
		}
		else
		{
			describeOfTask += "This is No " + to_string(workTask->index_) + " Task"
				+ "\tRequestTime is " + to_string(workTask->requestTime_)
				+ "\tOccurTime is " + to_string(time)
				+ "\tServerTime is " + to_string(workTask->serverTime_)
				+ "\tEndTime is " + to_string(time + workTask->serverTime_)
				+ ".\n";

			time += workTask->serverTime_;
		}

		vecAlreadyList.erase(workTask);
	}

	return describeOfTask;
}